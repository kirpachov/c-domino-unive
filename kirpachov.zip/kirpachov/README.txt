DOMINO 2D
==========
Progetto sviluppato in solitaria da Oleksandr Kirpachov (matricola 902835)
per il corso di Introduzione Alla Programmazione(2023/2024)
presso l'Università Ca' Foscari di Venezia.

https://github.com/kirpachov/c-domino-unive

I sorgenti sono nella cartella src.

La documentazione (generata con doxygen) è nella cartella doc.