var searchData=
[
  ['log_5fevent_0',['log_Event',['../structlog__Event.html',1,'']]]
];
