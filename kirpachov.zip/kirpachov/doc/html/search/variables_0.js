var searchData=
[
  ['top_5fleft_0',['top_left',['../structNode.html#a517ae2cce55d11833373584f9bf42812',1,'Node']]],
  ['top_5fleft_5fmove_1',['top_left_move',['../structNode.html#a10eb782ce826039793ffb0c7813b24f7',1,'Node']]]
];
